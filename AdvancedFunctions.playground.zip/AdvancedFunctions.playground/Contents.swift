func nameCombinator(firstName: String, lastName: String) -> String {
    return "\(firstName) \(lastName)"
}
func challenge(factor1: Int, factor2: Int, limit: Int){
    for number in 0...limit {
        if number % factor1 == 0 && number % factor2 == 0 {
            print("Lambda School")
        }else if number % factor1 == 0 {
            print("Lambda")
        }else if number % factor2 == 0 {
            print("School")
        }else {
            print (number)
    }
    }}
challenge(factor1: 2, factor2: 6, limit: 250)
